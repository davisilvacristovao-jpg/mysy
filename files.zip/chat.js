export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).end();

  try {
    const { messages } = req.body;

    const contents = messages.map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }],
    }));

    const MODEL = "gemini-2.5-flash";

    const r = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": process.env.GEMINI_API_KEY,
        },
        body: JSON.stringify({
          system_instruction: {
            parts: [
              {
                text: "Você é a Mysy, uma assistente simpática e prestativa. Responda sempre em português do Brasil.",
              },
            ],
          },
          contents,
        }),
      }
    );

    const data = await r.json();

    if (!r.ok) {
      console.error("Erro Gemini:", JSON.stringify(data));
      return res.status(200).json({ reply: "Erro ao responder. Verifique a chave e o modelo nos Logs da Vercel." });
    }

    res.status(200).json({
      reply: data.candidates?.[0]?.content?.parts?.[0]?.text ?? "Não consegui responder agora.",
    });
  } catch (e) {
    console.error(e);
    res.status(200).json({ reply: "Erro inesperado no servidor." });
  }
}
